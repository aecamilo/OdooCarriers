# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError

from .shipping_hub_client import ShippingHubClient

DEFAULT_SANDBOX_URL = 'http://127.0.0.1:3000'
DEFAULT_PRODUCTION_URL = 'https://api.shippingconnector.eu'


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    shipping_hub_api_token = fields.Char(
        string='Shipping Hub API Token',
        config_parameter='shipping_hub_connector.api_token',
    )
    shipping_hub_environment = fields.Selection(
        [
            ('sandbox', 'Sandbox'),
            ('production', 'Production'),
        ],
        string='Environment',
        default='sandbox',
        config_parameter='shipping_hub_connector.environment',
    )
    shipping_hub_auto_generate = fields.Boolean(
        string='Generate label on picking validation',
        default=True,
        config_parameter='shipping_hub_connector.auto_generate',
    )
    shipping_hub_auto_attach = fields.Boolean(
        string='Attach label PDF to Chatter',
        default=True,
        config_parameter='shipping_hub_connector.auto_attach',
    )
    shipping_hub_gateway_base_url = fields.Char(
        string='Gateway base URL (override)',
        config_parameter='shipping_hub_connector.gateway_base_url',
        help='Leave empty to use the default URL for the selected environment.',
    )

    @api.model
    def _shipping_hub_resolve_base_url(self, environment=None, override=None):
        icp = self.env['ir.config_parameter'].sudo()
        env_name = environment or icp.get_param(
            'shipping_hub_connector.environment', 'sandbox'
        )
        url = (override or icp.get_param('shipping_hub_connector.gateway_base_url') or '').strip()
        if url:
            return url.rstrip('/')
        if env_name == 'production':
            return DEFAULT_PRODUCTION_URL
        return DEFAULT_SANDBOX_URL

    @api.model
    def _shipping_hub_get_api_token(self):
        return (
            self.env['ir.config_parameter']
            .sudo()
            .get_param('shipping_hub_connector.api_token', '')
            or ''
        )

    @api.model
    def _shipping_hub_auto_generate_enabled(self):
        return (
            self.env['ir.config_parameter']
            .sudo()
            .get_param('shipping_hub_connector.auto_generate', 'True')
            == 'True'
        )

    @api.model
    def _shipping_hub_auto_attach_enabled(self):
        return (
            self.env['ir.config_parameter']
            .sudo()
            .get_param('shipping_hub_connector.auto_attach', 'True')
            == 'True'
        )

    def action_test_shipping_hub_connection(self):
        self.ensure_one()
        base_url = self._shipping_hub_resolve_base_url(
            self.shipping_hub_environment,
            self.shipping_hub_gateway_base_url,
        )
        token = self.shipping_hub_api_token or self._shipping_hub_get_api_token()
        ShippingHubClient(base_url, token).test_connection()
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Shipping Hub'),
                'message': _('Connection successful. Token and gateway are reachable.'),
                'type': 'success',
                'sticky': False,
            },
        }
