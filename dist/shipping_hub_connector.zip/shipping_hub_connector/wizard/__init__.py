# -*- coding: utf-8 -*-

from . import shipping_hub_batch_labels_wizard
